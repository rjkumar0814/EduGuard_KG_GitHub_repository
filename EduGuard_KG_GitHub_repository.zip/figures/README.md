Figures in this directory should be generated from empirical output files.
Do not upload reconstructed ROC/PR/calibration/temporal/robustness curves
as if they were empirical figures until the underlying point-level or
window-level results are available.
